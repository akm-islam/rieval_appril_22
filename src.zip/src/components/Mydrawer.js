import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Slider from '@material-ui/core/Slider';
import "./Mydrawer.css";
import * as $ from 'jquery';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Checkbox from '@material-ui/core/Checkbox';
const useStyles = makeStyles((theme) => ({
  root: {
    width: '100%',
  },
  listroot:{
    width: '100%',
    maxWidth: 360,
    backgroundColor: '#606060', 
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
  },
}));

function valuetext(value) {
  return `${value}°C`;
}
function RangeSlider(props) {
  //console.log(props.props2)
  const classes = useStyles();
  const [value, setValue] = React.useState([0, 50]);
//------------For list and chckbox
  const [checked, setChecked] = React.useState([0]);
  const handleToggle = (value) => () => {
    const currentIndex = checked.indexOf(value);
    const newChecked = [...checked];

    if (currentIndex === -1) {
      newChecked.push(value);
    } else {
      newChecked.splice(currentIndex, 1);
    }
    setChecked(newChecked);
  };
//----------------
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const handlecommittedChange = (event, newValue) => {
    var myfunc=props.props2
    myfunc(newValue)
  };
  return (
    <div className="Mydrawer_parent">
    <div>
      <ExpansionPanel>
        <ExpansionPanelSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
        <Typography className={classes.heading}>Select Model</Typography>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
        <div className="CheckboxContainer" style={{width:$('.mydrawer').width()}}>
          <List className={classes.listroot}>
            {props.all_models.map((value) => {
              const labelId = `checkbox-list-label-${value}`;
              return (
                <ListItem key={value} role={undefined} dense button onClick={handleToggle(value)}>
                  <ListItemIcon>
                    <Checkbox
                      edge="start"
                      tabIndex={-1}
                      disableRipple
                      inputProps={{ 'aria-labelledby': labelId }}
                    />
                  </ListItemIcon>
                  <ListItemText id={labelId} primary={value} />
                </ListItem>
              );
            })}
          </List>
        </div>          
        </ExpansionPanelDetails>
      </ExpansionPanel>
    </div>
    <div className="rangeSlidercontainer">
    <div className="rangeslider_title">Set Range</div>
    {// change the width here from props.mywidth
    }
    <div className="rangeslider" style={{width:$('.mydrawer').width()}}>
      <Slider
        value={value}
        onChange={handleChange}
        onChangeCommitted={handlecommittedChange}
        valueLabelDisplay="auto"
        aria-labelledby="range-slider"
        getAriaValueText={valuetext}
        valueLabelDisplay="on"
        min={props.slider_min}
        max={props.slider_max}
      />
    </div>
    </div>
    </div>
  );
}
export default RangeSlider;

//https://material-ui.com/api/slider/
//https://material-ui.com/components/expansion-panels/
//https://material-ui.com/api/checkbox/